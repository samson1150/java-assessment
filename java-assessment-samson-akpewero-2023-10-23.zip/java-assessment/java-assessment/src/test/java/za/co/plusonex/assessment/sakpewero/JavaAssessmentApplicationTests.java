package za.co.plusonex.assessment.sakpewero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaAssessmentApplicationTests {

    @Test
    void contextLoads() {
    }

}

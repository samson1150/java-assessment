package za.co.plusonex.assessment.sakpewero.controllers;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import za.co.plusonex.assessment.sakpewero.model.Account;
import za.co.plusonex.assessment.sakpewero.model.Transaction;
import za.co.plusonex.assessment.sakpewero.model.User;
import za.co.plusonex.assessment.sakpewero.service.ExchangeRateService;
import za.co.plusonex.assessment.sakpewero.service.TransactionService;

import java.time.LocalDateTime;
import java.util.Currency;

import static org.hamcrest.Matchers.closeTo;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.is;

@WebMvcTest(TransactionController.class)
public class TransactionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private TransactionService transactionService;
    @MockBean
    private ExchangeRateService exchangeRateService; // mock the exchange rate service


    private Transaction mockTransaction() {
        // Mocking Users
        User sourceUser = new User();
        sourceUser.setId(101L);
        sourceUser.setUsername("SourceUser");

        User destinationUser = new User();
        destinationUser.setId(102L);
        destinationUser.setUsername("DestinationUser");

        // Mocking Accounts
        Account sourceAccount = new Account();
        sourceAccount.setId(1001L);
        sourceAccount.setBalance(500.0);
        sourceAccount.setCurrency(Currency.getInstance("ZAR"));
        sourceAccount.setUser(sourceUser);

        Account destinationAccount = new Account();
        destinationAccount.setId(1002L);
        destinationAccount.setBalance(200.0);
        destinationAccount.setCurrency(Currency.getInstance("ZAR"));
        destinationAccount.setUser(destinationUser);

        // Mocking Transaction
        Transaction transaction = new Transaction(
                sourceAccount,
                destinationAccount,
                100.0,
                LocalDateTime.now(),
                Transaction.TransactionType.TRANSFER,
                Transaction.TransactionStatus.SUCCESS
        );

        transaction.setId(1L);

        return transaction;
    }

    private Transaction mockDifferentCurrencyTransaction() {
        User sourceUser = new User();
        sourceUser.setId(101L);
        sourceUser.setUsername("SourceUser");

        User destinationUser = new User();
        destinationUser.setId(102L);
        destinationUser.setUsername("DestinationUser");

        Account sourceAccount = new Account();
        sourceAccount.setId(1001L);
        sourceAccount.setBalance(500.0);
        sourceAccount.setCurrency(Currency.getInstance("ZAR"));
        sourceAccount.setUser(sourceUser);

        Account destinationAccount = new Account();
        destinationAccount.setId(1002L);
        destinationAccount.setBalance(200.0);
        destinationAccount.setCurrency(Currency.getInstance("USD"));
        destinationAccount.setUser(destinationUser);

        double exchangeRate = 0.067; // hypothetical exchange rate
        double transferredAmountInUSD = 100.0 * exchangeRate;

        Transaction transaction = new Transaction(
                sourceAccount,
                destinationAccount,
                transferredAmountInUSD,
                LocalDateTime.now(),
                Transaction.TransactionType.TRANSFER,
                Transaction.TransactionStatus.SUCCESS
        );
        transaction.setId(1L);
        return transaction;

    }

    @Test
    public void testMakeTransfer() throws Exception {
        Transaction transaction = mockTransaction();
        when(transactionService.processTransaction(any(Transaction.class))).thenReturn(transaction);

        String transactionPayload = "{"
                + "\"id\": 1,"
                + "\"sourceAccount\": {\"id\": 1001, \"name\": \"SourceAccountName\", \"user\": {\"id\": 101, \"name\": \"SourceUser\"}},"
                + "\"destinationAccount\": {\"id\": 1002, \"name\": \"DestinationAccountName\", \"user\": {\"id\": 102, \"name\": \"DestinationUser\"}},"
                + "\"amount\": 100.0,"
                + "\"type\": \"TRANSFER\","
                + "\"status\": \"SUCCESS\""
                + "}";

        mockMvc.perform(post("/transactions/transfer")
                        .contentType("application/json")
                        .content(transactionPayload))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.sourceAccount.id", is(1001)))
                .andExpect(jsonPath("$.destinationAccount.id", is(1002)))
                .andExpect(jsonPath("$.amount", is(100.0)))
                .andExpect(jsonPath("$.type", is("TRANSFER")))
                .andExpect(jsonPath("$.status", is("SUCCESS")));
    }


    @Test
    public void testMakeTransferDifferentCurrency() throws Exception {
        Transaction transaction = mockDifferentCurrencyTransaction();
        when(transactionService.processTransaction(any(Transaction.class))).thenReturn(transaction);
        when(exchangeRateService.getExchangeRate(Currency.getInstance("ZAR"), Currency.getInstance("USD"))).thenReturn(0.067);

        String transactionPayload = "{"
                + "\"id\": 2,"
                + "\"sourceAccount\": {\"id\": 1001, \"currency\": \"ZAR\", \"user\": {\"id\": 101, \"username\": \"SourceUser\"}},"
                + "\"destinationAccount\": {\"id\": 1002, \"currency\": \"USD\", \"user\": {\"id\": 102, \"username\": \"DestinationUser\"}},"
                + "\"amount\": 100.0,"  // Amount in source currency (ZAR)
                + "\"type\": \"TRANSFER\","
                + "\"status\": \"SUCCESS\""
                + "}";


        mockMvc.perform(post("/transactions/transfer")
                        .contentType("application/json")
                        .content(transactionPayload))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.sourceAccount.currency", is("ZAR")))
                .andExpect(jsonPath("$.destinationAccount.currency", is("USD")))
                .andExpect(jsonPath("$.amount", closeTo(6.7, 0.001))); // 100 ZAR converted to USD using our hypothetical rate
    }

    @Test
    public void testGetTransactionById() throws Exception {
        Transaction transaction = mockTransaction();
        when(transactionService.getTransactionById(1L)).thenReturn(transaction);

        mockMvc.perform(get("/transactions/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.sourceAccount.id", is(1001)))
                .andExpect(jsonPath("$.destinationAccount.id", is(1002)))
                .andExpect(jsonPath("$.amount", is(100.0)))
                .andExpect(jsonPath("$.type", is("TRANSFER")))
                .andExpect(jsonPath("$.status", is("SUCCESS")));
    }

}

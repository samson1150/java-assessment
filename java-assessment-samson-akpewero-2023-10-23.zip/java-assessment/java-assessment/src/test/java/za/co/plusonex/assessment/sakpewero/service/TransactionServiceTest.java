package za.co.plusonex.assessment.sakpewero.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

import za.co.plusonex.assessment.sakpewero.model.Account;
import za.co.plusonex.assessment.sakpewero.model.Transaction;
import za.co.plusonex.assessment.sakpewero.model.User;
import za.co.plusonex.assessment.sakpewero.repository.TransactionRepository;

import java.util.Optional;

class TransactionServiceTest {

    @InjectMocks
    private TransactionService service;

    @Mock
    private TransactionRepository transactionRepository;
    @Mock
    private TransferService transferService;
    @Mock
    private PaymentService paymentService;

    private Transaction transaction;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);


        transaction = new Transaction();
        transaction.setAmount(100.0);
        transaction.setId(1L);


        Account sourceAccount = new Account();
        Account destinationAccount = new Account();

        sourceAccount.setBalance(1000.0);
        destinationAccount.setBalance(1000.0);

        transaction.setSourceAccount(sourceAccount);
        transaction.setDestinationAccount(destinationAccount);
        transaction.setType(Transaction.TransactionType.PAYMENT);
        User user = new User();
        destinationAccount.setUser(user);

    }

    @Test
    void processTransaction_PaymentType() {
        service.processTransaction(transaction);

        verify(paymentService, times(1)).pay(any(Account.class), any(User.class), any(Double.class));
        verify(transferService, never()).transfer(any(Account.class), any(Account.class), any(Double.class));
        verify(transactionRepository, times(1)).save(transaction);
    }

    @Test
    void processTransaction_TransferType() {
        transaction.setType(Transaction.TransactionType.TRANSFER);
        service.processTransaction(transaction);

        verify(transferService, times(1)).transfer(any(Account.class), any(Account.class), any(Double.class));
        verify(paymentService, never()).pay(any(Account.class), any(User.class), any(Double.class));
        verify(transactionRepository, times(1)).save(transaction);
    }

    @Test
    void getTransactionById_Success() {
        Long transactionId = 1L;
        Transaction expectedTransaction = transaction;
        expectedTransaction.setId(transactionId);

        when(transactionRepository.findById(transactionId)).thenReturn(Optional.of(expectedTransaction));

        Transaction actualTransaction = service.getTransactionById(transactionId);

        assertNotNull(actualTransaction);
        assertEquals(expectedTransaction, actualTransaction);
    }


}

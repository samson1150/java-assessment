package za.co.plusonex.assessment.sakpewero.controllers;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import za.co.plusonex.assessment.sakpewero.service.ExchangeRateService;

import java.io.InputStream;
import java.util.Currency;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class ExchangeRateControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ExchangeRateService exchangeRateService;

    @Test
    public void testFetchRate() throws Exception {
        when(exchangeRateService.getExchangeRate(Currency.getInstance("ZAR"), Currency.getInstance("USD"))).thenReturn(1.5);

        mockMvc.perform(get("/api/exchangerates/fetchRate")
                        .param("from", "ZAR")
                        .param("to", "USD"))
                .andExpect(status().isOk())
                .andExpect(content().string("1.5"));

        verify(exchangeRateService, times(1)).getExchangeRate(Currency.getInstance("ZAR"), Currency.getInstance("USD"));
    }

    @Test
    public void testUploadCSV() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "rates.csv", "text/csv", "USD,SGD,1.5".getBytes());

        doNothing().when(exchangeRateService).updateRatesFromCSV(any(InputStream.class));

        mockMvc.perform(multipart("/api/exchangerates/uploadCSV").file(file))
                .andExpect(status().isOk())
                .andExpect(content().string("CSV processed successfully"));

        verify(exchangeRateService, times(1)).updateRatesFromCSV(any(InputStream.class));
    }
}

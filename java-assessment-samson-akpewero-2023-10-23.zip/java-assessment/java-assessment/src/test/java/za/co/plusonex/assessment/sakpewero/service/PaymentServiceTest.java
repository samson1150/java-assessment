package za.co.plusonex.assessment.sakpewero.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import za.co.plusonex.assessment.sakpewero.exception.InsufficientFundsException;
import za.co.plusonex.assessment.sakpewero.model.Account;
import za.co.plusonex.assessment.sakpewero.model.Transaction;
import za.co.plusonex.assessment.sakpewero.model.User;
import za.co.plusonex.assessment.sakpewero.repository.TransactionRepository;

import java.util.ArrayList;
import java.util.Currency;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class PaymentServiceTest {

    @InjectMocks
    private PaymentService service;

    @Mock
    private ExchangeRateService exchangeRateService;
    @Mock
    private TransactionRepository transactionRepository;

    private Account from;
    private Account to;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        from = new Account();
        to = new Account();
        from.setBalance(1000.0);
        to.setBalance(1000.0);

        Currency fromCurrency = Currency.getInstance("ZAR");
        Currency toCurrency = Currency.getInstance("USD");

        from.setCurrency(fromCurrency);
        to.setCurrency(toCurrency);

        User toUser = new User();
        List<Account> accountsForToUser = new ArrayList<>();
        accountsForToUser.add(to);
        toUser.setAccounts(accountsForToUser);

        to.setUser(toUser);
    }


    @Test
    void pay_Success_SameCurrency() {
        to.setCurrency(from.getCurrency());
        service.pay(from, to.getUser(), 100.0);

        assertEquals(900.0, from.getBalance());
        assertEquals(1100.0, to.getBalance());
        verify(transactionRepository, times(1)).save(any(Transaction.class));
    }

    @Test
    void pay_Success_DifferentCurrency() {
        when(exchangeRateService.getExchangeRate(from.getCurrency(), to.getCurrency())).thenReturn(0.8);

        service.pay(from, to.getUser(), 100.0);

        assertEquals(920.0, from.getBalance());
        assertEquals(1080.0, to.getBalance()); // As per 0.8 rate
        verify(transactionRepository, times(1)).save(any(Transaction.class));
    }


    @Test
    void pay_InsufficientFunds() {
        when(exchangeRateService.getExchangeRate(from.getCurrency(), to.getCurrency())).thenReturn(1.5); // 1 ZAR = 1.5 USD for this test

        Exception exception = assertThrows(InsufficientFundsException.class, () -> {
            service.pay(from, to.getUser(), 1100.0);  // The effective amount after conversion will be 1650.0
        });

        assertTrue(exception.getMessage().contains("Insufficient funds"));
    }

}

package za.co.plusonex.assessment.sakpewero.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import za.co.plusonex.assessment.sakpewero.model.ExchangeRate;
import za.co.plusonex.assessment.sakpewero.repository.ExchangeRateRepository;

import java.util.Currency;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class ExchangeRateServiceTest {

    @InjectMocks
    private ExchangeRateService service;

    @Mock
    private ExchangeRateRepository repository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getExchangeRate_FromDB() {
        Currency from = Currency.getInstance("USD");
        Currency to = Currency.getInstance("ZAR");
        when(repository.findByBaseCurrencyAndTargetCurrency(from.getCurrencyCode(), to.getCurrencyCode()))
            .thenReturn(Optional.of(new ExchangeRate(from.getCurrencyCode(), to.getCurrencyCode(), 0.8)));

        Double rate = service.getExchangeRate(from, to);

        assertEquals(0.8, rate);
    }
}

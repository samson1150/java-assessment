package za.co.plusonex.assessment.sakpewero.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import za.co.plusonex.assessment.sakpewero.model.User;
import za.co.plusonex.assessment.sakpewero.repository.UserRepository;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceTest {

    @InjectMocks
    private UserService service;

    @Mock
    private UserRepository userRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void registerUser_Success() {
        User user = new User();
        when(userRepository.findByUsername(user.getUsername())).thenReturn(Optional.empty());
        when(userRepository.save(any(User.class))).thenReturn(user);

        User savedUser = service.registerUser(user);


        assertNotNull(savedUser);
        verify(userRepository, times(1)).save(user);
    }

    @Test
    void registerUser_UsernameTaken() {
        User user = new User();
        when(userRepository.findByUsername(user.getUsername())).thenReturn(Optional.of(user));

        Exception exception = assertThrows(IllegalStateException.class, () -> {
            service.registerUser(user);
        });

        assertTrue(exception.getMessage().contains("Username already taken"));
    }

    @Test
    void getUserById_Success() {
        Long userId = 1L;
        User expectedUser = new User();
        expectedUser.setId(userId);
        when(userRepository.findById(userId)).thenReturn(Optional.of(expectedUser));


        User actualUser = service.getUserById(userId);


        assertNotNull(actualUser);
        assertEquals(expectedUser, actualUser);
        verify(userRepository, times(1)).findById(userId);
    }

}

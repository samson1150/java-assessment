package za.co.plusonex.assessment.sakpewero.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.co.plusonex.assessment.sakpewero.model.Transaction;
import za.co.plusonex.assessment.sakpewero.repository.TransactionRepository;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;
    private final TransferService transferService;
    private final PaymentService paymentService;

    @Autowired
    public TransactionService(TransactionRepository transactionRepository, TransferService transferService, PaymentService paymentService) {
        this.transactionRepository = transactionRepository;
        this.transferService = transferService;
        this.paymentService = paymentService;
    }

    public Transaction processTransaction(Transaction transaction) {

        // null checks
        if (transaction == null) {
            throw new IllegalArgumentException("Transaction cannot be null");
        }


        if (transaction.getType() == Transaction.TransactionType.TRANSFER) {
            transferService.transfer(transaction.getSourceAccount(), transaction.getDestinationAccount(), transaction.getAmount());
        } else if (transaction.getType() == Transaction.TransactionType.PAYMENT) {
            paymentService.pay(transaction.getSourceAccount(), transaction.getDestinationAccount().getUser(), transaction.getAmount());
        } else {
            throw new IllegalArgumentException("Invalid transaction type");
        }

        return transactionRepository.save(transaction);
    }

    public Transaction getTransactionById(Long transactionId) {
        return transactionRepository.findById(transactionId)
                .orElseThrow(() -> new IllegalArgumentException("Transaction not found for id: " + transactionId));
    }
}

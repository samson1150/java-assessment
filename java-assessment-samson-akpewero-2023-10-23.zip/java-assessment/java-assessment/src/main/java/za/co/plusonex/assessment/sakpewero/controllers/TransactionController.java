package za.co.plusonex.assessment.sakpewero.controllers;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import za.co.plusonex.assessment.sakpewero.model.Transaction;
import za.co.plusonex.assessment.sakpewero.service.TransactionService;

@RestController
@RequestMapping("/transactions")
@Slf4j
public class TransactionController {

    private final TransactionService transactionService;

    @Autowired
    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @PostMapping("/transfer")
    public ResponseEntity<Transaction> makeTransfer(@RequestBody Transaction transaction) {
        if (transaction.getType() == null || transaction.getAmount() == null) {
            return ResponseEntity.badRequest().body(null);
        }
        Transaction processedTransaction = transactionService.processTransaction(transaction);
        log.info("Processed transaction: {}", processedTransaction);
        return ResponseEntity.ok(processedTransaction);
    }

    @GetMapping("/{transactionId}")
    public ResponseEntity<Transaction> getTransactionById(@PathVariable Long transactionId) {
        Transaction transaction = transactionService.getTransactionById(transactionId);
        log.info("Transaction: {}", transaction);
        return ResponseEntity.ok(transaction);
    }
}

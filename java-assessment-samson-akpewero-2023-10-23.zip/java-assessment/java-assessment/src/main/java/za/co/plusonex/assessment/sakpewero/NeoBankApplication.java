package za.co.plusonex.assessment.sakpewero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeoBankApplication {

    public static void main(String[] args) {
        SpringApplication.run(NeoBankApplication.class, args);
    }

}

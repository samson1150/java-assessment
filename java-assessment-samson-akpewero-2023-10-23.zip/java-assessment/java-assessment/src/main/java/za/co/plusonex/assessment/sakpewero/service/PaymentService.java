package za.co.plusonex.assessment.sakpewero.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.co.plusonex.assessment.sakpewero.exception.InsufficientFundsException;
import za.co.plusonex.assessment.sakpewero.model.Account;
import za.co.plusonex.assessment.sakpewero.model.Transaction;
import za.co.plusonex.assessment.sakpewero.model.User;
import za.co.plusonex.assessment.sakpewero.repository.TransactionRepository;

import java.time.LocalDateTime;

@Service
public class PaymentService {

    private final ExchangeRateService exchangeRateService;
    private final TransactionRepository transactionRepository;

    @Autowired
    public PaymentService(ExchangeRateService exchangeRateService, TransactionRepository transactionRepository) {
        this.exchangeRateService = exchangeRateService;
        this.transactionRepository = transactionRepository;
    }

    public void pay(Account from, User toUser, Double amount) {
        // assuming the receiving user's default account is the first one in the list
        Account to = toUser.getAccounts().get(0);

        if (from == null || to == null || from.getBalance() == null || to.getBalance() == null) {
            throw new IllegalArgumentException("Accounts cannot be null.");
        }


        if (!from.getCurrency().equals(to.getCurrency())) {
            Double exchangeRate = exchangeRateService.getExchangeRate(from.getCurrency(), to.getCurrency());
            amount *= exchangeRate;
        }

        if (from.getBalance() < amount) {
            throw new InsufficientFundsException("Insufficient funds in source account.");
        }


        from.setBalance(from.getBalance() - amount);
        to.setBalance(to.getBalance() + amount);
        Transaction transaction = new Transaction(from, toUser.getAccounts().get(0), amount, LocalDateTime.now(), Transaction.TransactionType.PAYMENT, Transaction.TransactionStatus.SUCCESS);
        transactionRepository.save(transaction);
    }
}

package za.co.plusonex.assessment.sakpewero.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import za.co.plusonex.assessment.sakpewero.model.Transaction;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {}

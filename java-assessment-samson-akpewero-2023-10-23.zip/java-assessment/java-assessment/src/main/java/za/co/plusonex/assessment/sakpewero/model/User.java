package za.co.plusonex.assessment.sakpewero.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name = "app_user")
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;


    @OneToMany(mappedBy = "user")
    private List<Account> accounts;

}

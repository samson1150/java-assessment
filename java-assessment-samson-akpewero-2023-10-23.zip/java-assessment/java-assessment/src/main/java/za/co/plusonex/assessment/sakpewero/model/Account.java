package za.co.plusonex.assessment.sakpewero.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Currency;

@Entity
@Data
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double balance;
    private Currency currency;


    @ManyToOne
    private User user;


}

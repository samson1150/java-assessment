package za.co.plusonex.assessment.sakpewero.controllers;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import za.co.plusonex.assessment.sakpewero.service.ExchangeRateService;

import java.io.IOException;
import java.util.Currency;

@RestController
@RequestMapping("/api/exchangerates")
@Slf4j
public class ExchangeRateController {

    private final ExchangeRateService exchangeRateService;

    @Autowired
    public ExchangeRateController(ExchangeRateService exchangeRateService) {
        this.exchangeRateService = exchangeRateService;
    }



    @GetMapping("/fetchRate")
    public ResponseEntity<Double> getExchangeRate(@RequestParam String from, @RequestParam String to) {
        Double rate = exchangeRateService.getExchangeRate(Currency.getInstance(from), Currency.getInstance(to));
        log.info("Rate fetched: {}", rate);
        return ResponseEntity.ok(rate);
    }

    @PostMapping("/uploadCSV")
    public ResponseEntity<String> uploadCSV(@RequestParam("file") MultipartFile file) {
        try {
            exchangeRateService.updateRatesFromCSV(file.getInputStream());
            return ResponseEntity.ok("CSV processed successfully");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to process CSV");
        }
    }
}

package za.co.plusonex.assessment.sakpewero.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Account sourceAccount;

    @ManyToOne
    private Account destinationAccount;

    private Double amount;
    private LocalDateTime timestamp;
    private TransactionType type;
    private TransactionStatus status;

    public Transaction(Account from, Account to, Double amount, LocalDateTime now,
                       TransactionType transactionType, TransactionStatus transactionStatus) {
        this.sourceAccount = from;
        this.destinationAccount = to;
        this.amount = amount;
        this.timestamp = now;
        this.type = transactionType;
        this.status = transactionStatus;
    }

    public enum TransactionType {
        TRANSFER,
        PAYMENT
    }

    public enum TransactionStatus {
        SUCCESS,
        PENDING,
        FAILED
    }
}

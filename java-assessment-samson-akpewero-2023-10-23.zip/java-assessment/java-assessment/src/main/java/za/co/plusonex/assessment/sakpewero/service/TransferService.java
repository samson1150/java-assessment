package za.co.plusonex.assessment.sakpewero.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.co.plusonex.assessment.sakpewero.exception.InsufficientFundsException;
import za.co.plusonex.assessment.sakpewero.model.Account;
import za.co.plusonex.assessment.sakpewero.model.Transaction;
import za.co.plusonex.assessment.sakpewero.repository.TransactionRepository;

import java.time.LocalDateTime;

@Service
public class TransferService {

    private final ExchangeRateService exchangeRateService;
    private final TransactionRepository transactionRepository;

    @Autowired
    public TransferService(ExchangeRateService exchangeRateService, TransactionRepository transactionRepository) {
        this.exchangeRateService = exchangeRateService;
        this.transactionRepository = transactionRepository;
    }


    public void transfer(Account from, Account to, Double amount) {

        if (!from.getUser().equals(to.getUser())) {
            throw new IllegalArgumentException("Accounts do not belong to the same user.");
        }

        // If different currencies, convert the amount
        if (!from.getCurrency().equals(to.getCurrency())) {
            Double exchangeRate = exchangeRateService.getExchangeRate(from.getCurrency(), to.getCurrency());
            amount *= exchangeRate;
        }


        if (from.getBalance() < amount) {
            throw new InsufficientFundsException("Insufficient funds in source account.");
        }

        from.setBalance(from.getBalance() - amount);
        to.setBalance(to.getBalance() + amount);
        Transaction transaction = new Transaction(from, to, amount, LocalDateTime.now(),
                Transaction.TransactionType.TRANSFER, Transaction.TransactionStatus.SUCCESS);
        transactionRepository.save(transaction);
    }
}

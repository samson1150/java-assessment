package za.co.plusonex.assessment.sakpewero.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import za.co.plusonex.assessment.sakpewero.exception.CurrencyMismatchException;
import za.co.plusonex.assessment.sakpewero.model.ExchangeRate;
import za.co.plusonex.assessment.sakpewero.repository.ExchangeRateRepository;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Currency;
import java.util.Optional;

@Service
@Slf4j
public class ExchangeRateService {

    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${RAPID_API_CURRENCY_URL}")
    private String API_URL;

    @Value("${RAPID_API_KEY}")
    private String API_KEY;

    @Value("${RAPID_API_CURRENCY_HOST}")
    private String API_HOST;
    private final ExchangeRateRepository exchangeRateRepository;

    public ExchangeRateService(ExchangeRateRepository exchangeRateRepository) {
        this.exchangeRateRepository = exchangeRateRepository;
    }

    public Double getExchangeRate(Currency from, Currency to) {
        Optional<ExchangeRate> rateFromDb = exchangeRateRepository.findByBaseCurrencyAndTargetCurrency(from.getCurrencyCode(), to.getCurrencyCode());

        if (rateFromDb.isPresent()) {
            return rateFromDb.get().getRate();
        }

        try {
            Double fetchedRate = fetchFromApi(from, to);
            ExchangeRate newRate = new ExchangeRate(from.getCurrencyCode(), to.getCurrencyCode(), fetchedRate);
            exchangeRateRepository.save(newRate);
            return fetchedRate;
        } catch (RestClientException e) {
            return fetchFromCsv(from, to);
        }
    }

    private Double fetchFromApi(Currency from, Currency to) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-RapidAPI-Key", API_KEY);
        headers.set("X-RapidAPI-Host", API_HOST);
        HttpEntity<String> entity = new HttpEntity<>(headers);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(API_URL)
                .queryParam("from", from.getCurrencyCode())
                .queryParam("to", to.getCurrencyCode())
                .queryParam("q", 1.0);

        ResponseEntity<Double> response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, entity, Double.class);

        return response.getBody();
    }

    private Double fetchFromCsv(Currency from, Currency to) {
        Optional<ExchangeRate> rateFromCsv = exchangeRateRepository.findByBaseCurrencyAndTargetCurrency(from.getCurrencyCode(), to.getCurrencyCode());

        if (!rateFromCsv.isPresent()) {
            throw new CurrencyMismatchException("Exchange rate for given currencies not found.");
        }

        return rateFromCsv.get().getRate();
    }

    public void updateRatesFromCSV(InputStream csvContent) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(csvContent));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] values = line.split(",");
            ExchangeRate rate = new ExchangeRate(values[0], values[1], Double.valueOf(values[2]));
            exchangeRateRepository.save(rate);
        }
    }
}
